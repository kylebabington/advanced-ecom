// src/pages/HomePage.tsx
// This file is the home page component
export default function HomePage() {
    return (
      <div>
        <h2>Home</h2>
        <p>Next: Category dropdown + product list from FakeStoreAPI.</p>
      </div>
    )
  }
  