// src/pages/CartPage.tsx
// This file is the cart page component

export default function CartPage() {
    return (
      <div>
        <h2>Cart</h2>
        <p>Next: show cart items, totals, remove buttons, checkout.</p>
      </div>
    )
  }
  