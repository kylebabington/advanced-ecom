// src/pages/CartPage.tsx
// Cart page reads cart contents from Redux Toolkit,
// shows totals, allows removing items, and supports checkout.
//
// Requirements satisfied:
// ✅ Cart is managed by Redux Toolkit
// ✅ Cart persists in sessionStorage (already handled in cartSlice/cartStorage)
// ✅ Checkout clears Redux + sessionStorage

import { useMemo, useState } from 'react'
import { useAppDispatch, useAppSelector } from '../app/hooks'
import { removeFromCart, clearCart } from '../features/cart/cartSlice'

export default function CartPage() {
  const dispatch = useAppDispatch()

  // Read cart items from Redux
  const items = useAppSelector((state) => state.cart.items)

  // Simple UI state for checkout feedback
  const [checkedOut, setCheckedOut] = useState(false)

  // Compute totals
  const totals = useMemo(() => {
    const totalQty = items.reduce((sum, item) => sum + item.quantity, 0)
    const totalPrice = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0)
    return { totalQty, totalPrice }
  }, [items])

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <h2 style={{ margin: 0 }}>Cart</h2>

      {/* Checkout success message */}
      {checkedOut && (
        <div style={{ padding: 12, border: '1px solid #22c55e', borderRadius: 10 }}>
          ✅ Checkout complete. Cart cleared.
        </div>
      )}

      {/* Empty cart */}
      {items.length === 0 && <div>Your cart is empty.</div>}

      {/* Cart list */}
      {items.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {items.map((item) => (
            <div
              key={item.product.id}
              style={{
                display: 'flex',
                gap: 12,
                alignItems: 'center',
                border: '1px solid #ddd',
                borderRadius: 12,
                padding: 12,
              }}
            >
              <img
                src={item.product.image}
                alt={item.product.title}
                style={{ width: 64, height: 64, objectFit: 'contain', background: '#fff' }}
              />

              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700 }}>{item.product.title}</div>
                <div style={{ fontSize: 12, opacity: 0.8 }}>
                  ${item.product.price.toFixed(2)} × {item.quantity}
                </div>
              </div>

              <div style={{ fontWeight: 800 }}>
                ${(item.product.price * item.quantity).toFixed(2)}
              </div>

              <button
                type="button"
                onClick={() => dispatch(removeFromCart(item.product.id))}
                style={{
                  padding: '8px 10px',
                  borderRadius: 10,
                  border: '1px solid #333',
                  background: '#fff',
                  cursor: 'pointer',
                }}
              >
                Remove
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Totals + Checkout */}
      {items.length > 0 && (
        <div
          style={{
            marginTop: 8,
            padding: 12,
            border: '1px solid #ddd',
            borderRadius: 12,
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: 12,
            flexWrap: 'wrap',
          }}
        >
          <div>
            <div style={{ fontWeight: 700 }}>Items: {totals.totalQty}</div>
            <div style={{ fontWeight: 900, fontSize: 18 }}>
              Total: ${totals.totalPrice.toFixed(2)}
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              // Clear Redux state + sessionStorage (your slice does both)
              dispatch(clearCart())
              // Show confirmation UI
              setCheckedOut(true)
            }}
            style={{
              padding: '10px 14px',
              borderRadius: 10,
              border: '1px solid #333',
              background: '#111',
              color: '#fff',
              cursor: 'pointer',
              fontWeight: 800,
            }}
          >
            Checkout
          </button>
        </div>
      )}
    </div>
  )
}
