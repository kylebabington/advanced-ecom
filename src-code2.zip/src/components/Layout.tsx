// src/components/Layout.tsx
// This file is the layout component for the app
import { Outlet, Link } from 'react-router-dom'
import { useAppSelector } from '../app/hooks'

export default function Layout() {
  // ✅ Total cart quantity for nav display
  const totalQty = useAppSelector((state) =>
    state.cart.items.reduce((sum, item) => sum + item.quantity, 0)
  )

  return (
    <div style={{ maxWidth: 1100, margin: '0 auto', padding: 16 }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Link to="/" style={{ textDecoration: 'none' }}>
          <h1 style={{ margin: 0, color: 'black' }}>Kyle's Virtual Emporium</h1>
        </Link>

        <nav style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <Link to="/">Home</Link>
          <Link to="/cart">Cart ({totalQty})</Link>
        </nav>
      </header>

      <hr style={{ margin: '16px 0' }} />

      {/* ✅ Pages render here */}
      <Outlet />
    </div>
  )
}
