// src/components/ProductCard.tsx
// This component displays a product and allows adding it to the cart.
//
// Requirements satisfied:
// ✅ Displays product details
// ✅ Add to cart uses Redux Toolkit
// ✅ Image fallback if FakeStore image URL fails (404 etc.)

import { useState } from 'react'
import type { Product } from '../api/types'
import { useAppDispatch } from '../app/hooks'
import { addToCart } from '../features/cart/cartSlice'

// A small inline SVG placeholder image (no extra files needed).
// We URI-encode it so it works safely inside an <img src="...">.
const FALLBACK_IMAGE =
  'data:image/svg+xml;charset=UTF-8,' +
  encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" width="400" height="300">
      <rect width="100%" height="100%" fill="#f2f2f2"/>
      <text x="50%" y="50%" font-size="18" text-anchor="middle" fill="#777" font-family="Arial">
        Image not available
      </text>
    </svg>
  `)

type ProductCardProps = {
  product: Product
}

export default function ProductCard({ product }: ProductCardProps) {
  // Redux dispatch lets us fire actions like addToCart(product)
  const dispatch = useAppDispatch()

  // We keep a local imageSrc so we can swap to fallback if the original fails.
  const [imageSrc, setImageSrc] = useState(product.image)

  return (
    <div
      style={{
        border: '1px solid #ddd',
        borderRadius: 12,
        padding: 12,
        display: 'flex',
        flexDirection: 'column',
        gap: 10,
      }}
    >
      <div style={{ width: '100%', aspectRatio: '4 / 3', overflow: 'hidden', borderRadius: 10 }}>
        <img
          src={imageSrc}
          alt={product.title}
          style={{ width: '100%', height: '100%', objectFit: 'contain', background: '#fff' }}
          onError={() => {
            // If the image fails to load, swap to fallback.
            // This satisfies the "Image fallback if URL 404s" requirement.
            setImageSrc(FALLBACK_IMAGE)
          }}
        />
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        <div style={{ fontWeight: 700, lineHeight: 1.2 }}>{product.title}</div>

        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
          <div style={{ fontWeight: 700 }}>${product.price.toFixed(2)}</div>
          <div style={{ fontSize: 12, opacity: 0.75 }}>{product.category}</div>
        </div>

        <div style={{ fontSize: 12, opacity: 0.85 }}>
          Rating: {product.rating?.rate ?? 'N/A'} ({product.rating?.count ?? 0})
        </div>

        <div style={{ fontSize: 12, opacity: 0.9 }}>
          {product.description.length > 120
            ? product.description.slice(0, 120) + '…'
            : product.description}
        </div>
      </div>

      <button
        type="button"
        onClick={() => dispatch(addToCart(product))}
        style={{
          marginTop: 'auto',
          padding: '10px 12px',
          borderRadius: 10,
          border: '1px solid #333',
          background: '#111',
          color: '#fff',
          cursor: 'pointer',
          fontWeight: 700,
        }}
      >
        Add to cart
      </button>
    </div>
  )
}
